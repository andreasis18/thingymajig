package com.example.thingymajig

data class Recipe (
    var Id:Int = 0,
    var name:String ="",
    var description:String ="",
    var image:String =""
){}
