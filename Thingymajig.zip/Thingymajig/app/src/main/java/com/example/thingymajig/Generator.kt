package com.example.thingymajig

import android.app.Application

class Generator:Application(){
    companion object {
        var loggedUser:String =""
        var url:String ="http://riset.group/penir/penir_c1/"

    }
}
